"""Weapons package."""
