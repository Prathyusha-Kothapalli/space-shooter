"""Combat package."""
