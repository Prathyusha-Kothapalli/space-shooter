"""
Configuration package initialization.
"""
