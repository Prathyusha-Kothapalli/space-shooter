"""Effects package."""
