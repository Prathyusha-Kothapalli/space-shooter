"""Sector Map package."""
