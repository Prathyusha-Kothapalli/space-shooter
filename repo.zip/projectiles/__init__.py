"""Projectiles package."""
