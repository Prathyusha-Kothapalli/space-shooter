"""Waves package."""
