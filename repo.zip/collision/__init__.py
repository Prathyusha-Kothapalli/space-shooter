"""Collision package."""
