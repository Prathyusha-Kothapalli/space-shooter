"""Crafting package."""
