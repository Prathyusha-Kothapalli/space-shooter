"""Statistics package."""
