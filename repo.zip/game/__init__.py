"""Game session package."""
