"""Enemies package."""
